package com.example.codec

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(4, 15, 9)
    private val panel = Color.rgb(8, 28, 16)
    private val green = Color.rgb(112, 255, 154)
    private val dim = Color.rgb(55, 145, 82)
    private val red = Color.rgb(255, 48, 64)
    private lateinit var root: LinearLayout
    private var selected = "OTACON"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "▰  CODEC  //  $title"
            textSize = 20f; setTextColor(green); typeface = Typeface.MONOSPACE
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(header)
        val line = TextView(this).apply { text = "━━━━━━━━━━━━━━━━━━━━━━━━"; setTextColor(dim); textSize = 12f }
        root.addView(line)
        return root
    }

    private fun showHome() {
        val page = base("FREQUENCY MEMORY")
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        content.addView(label("SELECT CONTACT  /  STORED FREQUENCIES", 12, dim))
        contact(content, "OTACON", "140.85", "AVAILABLE")
        contact(content, "SNAKE", "141.80", "STANDBY")
        contact(content, "COLONEL", "140.15", "STANDBY")
        content.addView(label("\nLOCAL DEMO  •  NO REAL CALLS YET", 11, dim))
        content.addView(button("INITIATE TRANSMISSION", green) { showCalling() })
        content.addView(button("INCOMING CALL DEMO  [CALL]", red) { showIncoming() })
        content.addView(button("SETTINGS", dim) { showSettings() })
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun contact(parent: LinearLayout, name: String, freq: String, status: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundColor(panel)
        }
        val nameView = label("◉  $name", 18, green)
        card.addView(nameView)
        card.addView(label("FREQ $freq MHz     //     $status", 12, dim))
        card.addView(button("SELECT CONTACT", dim) { selected = name; showCalling() })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10)
        parent.addView(card, lp)
    }

    private fun showCalling() {
        val page = base("TRANSMISSION")
        page.addView(label("\nLINKING TO  $selected", 15, green))
        page.addView(label("\n[  SIGNAL SEARCH IN PROGRESS  ]", 13, dim))
        page.addView(label("\n\n       .  .  .  .  .", 22, green))
        page.addView(label("\nThis is a visual prototype.\nNo audio connection is active.", 13, dim))
        page.addView(button("END TRANSMISSION", red) { showHome() })
        page.addView(button("BACK TO MEMORY", dim) { showHome() })
        setContentView(page)
    }

    private fun showIncoming() {
        val page = base("INCOMING TRANSMISSION")
        page.addView(label("\n\n                 [CALL]", 27, red))
        page.addView(label("\nINCOMING SIGNAL\nUNKNOWN CONTACT  /  140.85 MHz", 14, green))
        page.addView(label("\nRINGING…", 13, dim))
        page.addView(button("ANSWER", green) { showActiveDemo() })
        page.addView(button("DECLINE", red) { showHome() })
        setContentView(page)
    }

    private fun showActiveDemo() {
        val page = base("SECURE CHANNEL")
        page.addView(label("\n       ◉  CODEC LINK  ◉", 19, green))
        page.addView(label("\nSNAKE                         YOU", 14, green))
        page.addView(label("\n[ MICROPHONE: DEMO ONLY ]", 12, dim))
        page.addView(label("\nConnection timer: DEMO", 12, dim))
        page.addView(button("MUTE  (VISUAL ONLY)", dim) { })
        page.addView(button("END CALL", red) { showHome() })
        setContentView(page)
    }

    private fun showSettings() {
        val page = base("SYSTEM SETTINGS")
        page.addView(label("\nOVERLAY [CALL]       PLANNED", 14, green))
        page.addView(label("BACKGROUND CALLS     PLANNED", 14, green))
        page.addView(label("P2P AUDIO / WEBRTC    PLANNED", 14, green))
        page.addView(label("\nThese features need additional native\nAndroid permissions and network setup.", 12, dim))
        page.addView(button("BACK", green) { showHome() })
        setContentView(page)
    }

    private fun label(textValue: String, size: Int, color: Int) = TextView(this).apply {
        text = textValue; textSize = size.toFloat(); setTextColor(color); typeface = Typeface.MONOSPACE
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun button(textValue: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = textValue; setTextColor(color); textSize = 12f; typeface = Typeface.MONOSPACE
        setBackgroundColor(panel); isAllCaps = false; setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8); layoutParams = lp
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
