# CODEC — Android prototype

This is a native Kotlin Android prototype inspired by the visual language of MGS1/MGS2.

## Included
- Frequency memory / demo contacts
- Outgoing-call visual state
- Incoming `[CALL]` visual demo
- Answer/decline navigation
- Settings screen showing planned native features

## Not implemented yet
- Real microphone/audio calls
- WebRTC/P2P signaling
- Background incoming calls/push notifications
- System-wide transparent overlay
- User accounts or real frequency registration

## Build
The included GitHub Actions workflow can build a debug APK in the cloud. The APK is an experimental prototype, not a finished messenger.
